# SnapshotManager
A neat little tool to manage MS SQL Server database snapshots
